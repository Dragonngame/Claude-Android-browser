# Remote Browser

An Android browser that Claude can control through a custom connector (MCP).

- The app has its own browser and a small MCP server on port 8765 (only reachable from the phone itself).
- ngrok in Termux gives the server a public https address.
- The connector URL is `https://<your-ngrok-domain>/<secret-key>/mcp`. The app makes the secret key; tap **Setup** in the app to copy the full URL.

Tools: open_url, get_page, find_elements, click_element, type_text, press_key, scroll, screenshot, tap, go_back, run_js, wait.

Run ngrok in Termux:

    termux-wake-lock
    termux-chroot ngrok http --url=YOUR-DOMAIN.ngrok-free.app 8765

Limits: the app must be open on screen while Claude uses it. Google account sign-in is blocked inside app browsers by Google.
